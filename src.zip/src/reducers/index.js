import { combineReducers } from "redux";
import user from './user'; // импортируем редьюсер 


export default combineReducers({ 
    user
});