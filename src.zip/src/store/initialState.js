const initialState = {
    user: [
        {
            passport: 5434543,
            name: 'Milie',
            age: 16,
        }
    ]

}
export default initialState;